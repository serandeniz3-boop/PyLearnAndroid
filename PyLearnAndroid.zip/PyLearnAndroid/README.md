# PyLearn Android (Kotlin + Compose)

Bu iskelet proje, yüklediğin KivyMD tabanlı PyLearn uygulamasını Android native yapıya taşımak için hazırlandı.

## Port edilen parçalar
- Dersler ekranı
- Ders detay ekranı
- Görevler ekranı
- Görev detay + test etme
- Günlük hedef
- XP / level / continue mantığı
- JSON içerikleri `assets/` altına taşıma
- Python görev testi ve kod çalıştırma için Chaquopy köprüsü

## Bilinçli olarak sade bırakılan kısım
- Stream output yok
- Hard stop yok
- Quiz ekranı henüz UI'ya bağlanmadı
- Tasarım henüz MVP düzeyinde

## Neden Chaquopy var?
Uygulama Kotlin'e taşındı, ama içerik Python eğitimi olduğu için kullanıcı kodunu Android içinde çalıştırmanın en pratik yolu gömülü Python runtime kullanmak. Chaquopy bunun için uygun köprü sağlar.

Eğer **uygulama içinde hiç Python kalmasın** istiyorsan, kod çalıştırıcı kısmını tamamen yeniden tasarlamak gerekir. O durumda seçenekler:
1. Kod çalıştırıcıyı kaldırmak
2. Sunucu/API üstünde Python koşturmak
3. Sadece belirli görev tipleri için Kotlin tabanlı mini değerlendirici yazmak

## Açılış
1. Android Studio ile klasörü aç
2. Gradle sync çalıştır
3. Gerekirse launcher icon eksikse Android Studio ile oluştur
4. Cihaz veya emülatörde çalıştır

## İçerik dosyaları
- `app/src/main/assets/lessons.json`
- `app/src/main/assets/tasks.json`
- `app/src/main/assets/quiz.json`

## Python köprüsü
- `app/src/main/python/sandbox_runner.py`
- `app/src/main/java/com/example/pylearn/runner/PythonRunner.kt`
