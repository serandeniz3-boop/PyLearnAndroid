package com.example.pylearn.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.pylearn.viewmodel.MainViewModel

@Composable
fun PyLearnApp(viewModel: MainViewModel = viewModel()) {
    val navController = rememberNavController()

    MaterialTheme {
        NavHost(navController = navController, startDestination = "home") {
            composable("home") {
                HomeScreen(navController, viewModel)
            }
            composable("lessons") {
                LessonsScreen(navController, viewModel)
            }
            composable("lesson/{lessonId}") { backStackEntry ->
                val lessonId = backStackEntry.arguments?.getString("lessonId").orEmpty()
                LessonDetailScreen(navController, viewModel, lessonId)
            }
            composable("tasks") {
                TasksScreen(navController, viewModel)
            }
            composable("task/{taskId}") { backStackEntry ->
                val taskId = backStackEntry.arguments?.getString("taskId").orEmpty()
                TaskDetailScreen(navController, viewModel, taskId)
            }
            composable("goal") {
                GoalScreen(navController, viewModel)
            }
            composable("runner") {
                RunnerScreen(navController, viewModel)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AppScaffold(
    title: String,
    canGoBack: Boolean,
    navController: NavHostController,
    content: @Composable (PaddingValues) -> Unit,
) {
    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text(title) },
                navigationIcon = {
                    if (canGoBack) {
                        IconButton(onClick = { navController.popBackStack() }) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Geri")
                        }
                    }
                }
            )
        }
    ) { padding -> content(padding) }
}

@Composable
private fun HomeScreen(navController: NavHostController, viewModel: MainViewModel) {
    val progress by viewModel.progress.collectAsState()
    LaunchedEffect(progress) { }

    AppScaffold(title = "PyLearn", canGoBack = false, navController = navController) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(viewModel.progressText())
                    Text(viewModel.dailyText())
                }
            }

            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(viewModel.continueText())
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = {
                            viewModel.continueLessonId()?.let { navController.navigate("lesson/$it") }
                        }) { Text("Derse Devam") }
                        OutlinedButton(onClick = {
                            viewModel.continueTaskId()?.let { navController.navigate("task/$it") }
                        }) { Text("Göreve Devam") }
                    }
                }
            }

            Button(onClick = { navController.navigate("lessons") }, modifier = Modifier.fillMaxWidth()) { Text("📚 Dersler") }
            Button(onClick = { navController.navigate("tasks") }, modifier = Modifier.fillMaxWidth()) { Text("🧩 Görevler") }
            Button(onClick = { navController.navigate("runner") }, modifier = Modifier.fillMaxWidth()) { Text("💻 Kod Çalıştırıcı") }
            Button(onClick = { navController.navigate("goal") }, modifier = Modifier.fillMaxWidth()) { Text("🎯 Hedef Ayarla") }
        }
    }
}

@Composable
private fun LessonsScreen(navController: NavHostController, viewModel: MainViewModel) {
    val lessons by viewModel.lessons.collectAsState()
    val progress by viewModel.progress.collectAsState()

    AppScaffold(title = "Dersler", canGoBack = true, navController = navController) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            items(lessons) { lesson ->
                val done = lesson.id in progress.doneLessons
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    onClick = {
                        viewModel.openLesson(lesson.id)
                        navController.navigate("lesson/${lesson.id}")
                    }
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text((if (done) "✅ " else "⬜ ") + lesson.title)
                        Spacer(Modifier.height(4.dp))
                        Text(lesson.body)
                    }
                }
            }
        }
    }
}

@Composable
private fun LessonDetailScreen(navController: NavHostController, viewModel: MainViewModel, lessonId: String) {
    val lesson = viewModel.lessonById(lessonId)
    LaunchedEffect(lessonId) { viewModel.openLesson(lessonId) }

    AppScaffold(title = "Ders", canGoBack = true, navController = navController) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text(lesson?.title ?: "Bulunamadı", style = MaterialTheme.typography.headlineSmall)
            Text(lesson?.body ?: "")
            Text("Örnek kod:")
            CodeBlock(lesson?.example ?: "")
        }
    }
}

@Composable
private fun TasksScreen(navController: NavHostController, viewModel: MainViewModel) {
    val tasks by viewModel.tasks.collectAsState()
    val progress by viewModel.progress.collectAsState()

    AppScaffold(title = "Görevler", canGoBack = true, navController = navController) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            Text(
                viewModel.tasksProgressText(),
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
            )
            LazyColumn(
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                items(tasks) { task ->
                    val done = task.id in progress.doneTasks
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        onClick = {
                            viewModel.openTask(task.id)
                            navController.navigate("task/${task.id}")
                        }
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text((if (done) "✅ " else "⬜ ") + task.title)
                            Spacer(Modifier.height(4.dp))
                            Text(task.desc)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TaskDetailScreen(navController: NavHostController, viewModel: MainViewModel, taskId: String) {
    val task = viewModel.taskById(taskId)
    val messages by viewModel.taskMessages.collectAsState()
    var code by rememberSaveable(taskId) { mutableStateOf(task?.starter ?: "") }

    AppScaffold(title = "Görev", canGoBack = true, navController = navController) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item {
                Text(task?.title ?: "Bulunamadı", style = MaterialTheme.typography.headlineSmall)
                Spacer(Modifier.height(8.dp))
                Text(task?.desc ?: "")
            }
            item {
                OutlinedTextField(
                    value = code,
                    onValueChange = { code = it },
                    label = { Text("Kod") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 10,
                    textStyle = MaterialTheme.typography.bodyMedium.copy(fontFamily = FontFamily.Monospace),
                )
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { if (task != null) viewModel.checkTask(task.id, code) }) { Text("Test Et") }
                    OutlinedButton(onClick = {
                        viewModel.sendCodeToRunner(code)
                        navController.navigate("runner")
                    }) { Text("Kod Çalıştırıcıya Aç") }
                }
            }
            item {
                Text("Çıktı:")
                CodeBlock(messages[taskId] ?: "")
            }
        }
    }
}

@Composable
private fun GoalScreen(navController: NavHostController, viewModel: MainViewModel) {
    val progress by viewModel.progress.collectAsState()
    var lessons by rememberSaveable { mutableStateOf(progress.dailyGoalLessons.toString()) }
    var tasks by rememberSaveable { mutableStateOf(progress.dailyGoalTasks.toString()) }

    AppScaffold(title = "Günlük Hedef", canGoBack = true, navController = navController) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text("Bugün kaç ders ve kaç görev hedefliyorsun?")
            OutlinedTextField(value = lessons, onValueChange = { lessons = it.filter(Char::isDigit) }, label = { Text("Ders hedefi") })
            OutlinedTextField(value = tasks, onValueChange = { tasks = it.filter(Char::isDigit) }, label = { Text("Görev hedefi") })
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = {
                    viewModel.saveDailyGoal(lessons.toIntOrNull() ?: 0, tasks.toIntOrNull() ?: 0)
                }) { Text("Kaydet") }
                OutlinedButton(onClick = {
                    viewModel.resetDailyGoal()
                    lessons = "1"
                    tasks = "1"
                }) { Text("Sıfırla") }
            }
            Text("Mevcut hedef: Ders ${progress.dailyGoalLessons}  •  Görev ${progress.dailyGoalTasks}")
        }
    }
}

@Composable
private fun RunnerScreen(navController: NavHostController, viewModel: MainViewModel) {
    val runner by viewModel.runner.collectAsState()

    AppScaffold(title = "Kod Çalıştırıcı", canGoBack = true, navController = navController) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item {
                OutlinedTextField(
                    value = runner.code,
                    onValueChange = viewModel::updateRunnerCode,
                    label = { Text("Kod") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 10,
                    textStyle = MaterialTheme.typography.bodyMedium.copy(fontFamily = FontFamily.Monospace),
                )
            }
            item {
                OutlinedTextField(
                    value = runner.input,
                    onValueChange = viewModel::updateRunnerInput,
                    label = { Text("Input değerleri (satır satır)") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 5,
                    textStyle = MaterialTheme.typography.bodyMedium.copy(fontFamily = FontFamily.Monospace),
                )
            }
            item {
                Button(onClick = viewModel::runCode, enabled = !runner.isRunning) { Text(if (runner.isRunning) "Çalışıyor..." else "Çalıştır") }
            }
            item {
                Text("Çıktı:")
                CodeBlock(runner.output)
            }
        }
    }
}

@Composable
private fun CodeBlock(text: String) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Text(
            text = if (text.isBlank()) " " else text,
            modifier = Modifier.padding(16.dp),
            fontFamily = FontFamily.Monospace,
        )
    }
}
