package com.example.pylearn.data

import android.content.Context
import com.example.pylearn.model.Lesson
import com.example.pylearn.model.QuizQuestion
import com.example.pylearn.model.TaskItem
import com.example.pylearn.model.TaskTest
import org.json.JSONArray

class ContentRepository(private val context: Context) {

    fun loadLessons(): List<Lesson> {
        val arr = JSONArray(context.assets.open("lessons.json").bufferedReader().use { it.readText() })
        return buildList {
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                add(
                    Lesson(
                        id = obj.optString("id"),
                        title = obj.optString("title"),
                        body = obj.optString("body"),
                        example = obj.optString("example"),
                    )
                )
            }
        }
    }

    fun loadTasks(): List<TaskItem> {
        val arr = JSONArray(context.assets.open("tasks.json").bufferedReader().use { it.readText() })
        return buildList {
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                val tests = obj.optJSONArray("tests") ?: JSONArray()
                add(
                    TaskItem(
                        id = obj.optString("id"),
                        title = obj.optString("title"),
                        desc = obj.optString("desc"),
                        starter = obj.optString("starter"),
                        tests = buildList {
                            for (j in 0 until tests.length()) {
                                val t = tests.getJSONObject(j)
                                add(
                                    TaskTest(
                                        input = t.optString("inp"),
                                        output = t.optString("out"),
                                    )
                                )
                            }
                        },
                    )
                )
            }
        }
    }

    fun loadQuiz(): List<QuizQuestion> {
        val arr = JSONArray(context.assets.open("quiz.json").bufferedReader().use { it.readText() })
        return buildList {
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                val choicesArr = obj.optJSONArray("choices") ?: JSONArray()
                add(
                    QuizQuestion(
                        id = obj.optString("id"),
                        question = obj.optString("question"),
                        choices = buildList {
                            for (j in 0 until choicesArr.length()) add(choicesArr.optString(j))
                        },
                        answerIndex = obj.optInt("answer_index"),
                        explain = obj.optString("explain"),
                    )
                )
            }
        }
    }
}
